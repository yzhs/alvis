package dcs.kva.group01.exercise05;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateFactory;
import java.util.Calendar;
import java.util.Date;

/**
 * This class contains the methods to check the validity of any certificate or the example
 * @author Jan Bauerdick
 */

public class Action {
	
	/**
	 * Load the certificate and save it
	 * @param filename Filename of the certificate
	 * @throws CertificateException File is not a x509 certificate
	 * @throws KeyStoreException Could not load cacert's keystore
	 * @throws IOException I/O Error
	 * @throws NoSuchAlgorithmException Algorithm unknown
	 * @throws NoSuchProviderException Provider unknown
	 * @throws InvalidKeyException Certificate's public key is invalid
	 */
	public static void loadCertificate(String filename) throws CertificateException, KeyStoreException, NoSuchAlgorithmException, IOException, InvalidKeyException, NoSuchProviderException {
		ValidityModelData.setX509((X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new FileInputStream(filename)));
		String cacertsStore = System.getProperty("java.home") + System.getProperty("file.separator") + "lib" + System.getProperty("file.separator") + "security" + System.getProperty("file.separator") + "cacerts";
		//default password for cacert keystore
		String cacertsPassword = "changeit";
		FileInputStream fis = new FileInputStream(cacertsStore);
		KeyStore cacerts = KeyStore.getInstance("jks");
		cacerts.load(fis, cacertsPassword.toCharArray());
		fis.close();
		X509Certificate x509 = ValidityModelData.getX509();
		String issuerInfo = x509.getIssuerX500Principal().toString();
		String[] issuerInfoSplitted = issuerInfo.split(",");
		String[] issuerNameSplitted = issuerInfoSplitted[1].split("=");
		String issuer = issuerNameSplitted[1].replace(" " , "_").toLowerCase().trim();
		X509Certificate x509CA = (X509Certificate) cacerts.getCertificate(issuer);
		ValidityModelData.setX509CA(x509CA);
		ValidityModelData.setCacerts(cacerts);
		CVMManager.getInstance().add(x509CA);
		checkCertificate();
	}
	
	/**
	 * Load the example keystore and save it
	 * @throws NoSuchAlgorithmException Algorithm unknown
	 * @throws CertificateException Error in keystore's certificates
	 * @throws KeyStoreException File is not a valid keystore
	 * @throws FileNotFoundException Example keystore is not in user's home
	 * @throws IOException I/O error
	 * @throws NoSuchProviderException Provider unknown
	 * @throws InvalidKeyException Certificate's public key is invalid
	 */
	public static void loadExampleChain() throws NoSuchAlgorithmException, KeyStoreException, FileNotFoundException, IOException, CertificateException, InvalidKeyException, NoSuchProviderException {
		String exampleStore = System.getProperty("user.dir") + System.getProperty("file.separator") + "keystore.jks";
		String examplePassword = "UNISIEGEN";
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(exampleStore), examplePassword.toCharArray());
		ValidityModelData.setExampleChain(ks);
		X509Certificate x509CA = (X509Certificate) ks.getCertificate("testca");
		X509Certificate x509 = (X509Certificate) ks.getCertificate("teilnehmer");
		ValidityModelData.setX509(x509);
		ValidityModelData.setX509CA(x509CA);
		checkExampleChain();
	}
	
	/**
	 * Check the validity of certificate by chain and shell model
	 * @param model The model to use (0==chain, 1==shell)
	 * @return True if certificate is valid by choosen model, false if not
	 * @throws InvalidKeyException Certificate's public key is invalid
	 * @throws NoSuchAlgorithmException Algorithm unknown
	 * @throws NoSuchProviderException Provider unknown
	 */
	public static boolean checkCertificate() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException {
		Calendar c = Calendar.getInstance();
		Date d = c.getTime();
		X509Certificate x509 = ValidityModelData.getX509();
		Date certDate = x509.getNotBefore();
		X509Certificate x509CA = ValidityModelData.getX509CA();		
		if (ValidityModelData.getModelType() == 0) {
			//Chain model
			try {
				x509.checkValidity(d);
				x509CA.checkValidity(certDate);
				x509.verify(x509CA.getPublicKey());
				ValidityModelData.setValid(true);
				return true;
			} catch (CertificateException e) {
				//x509 not valid in this moment or x509CA not valid when x509 got signed
				ValidityModelData.setValid(false);
				return false;
			} catch (SignatureException e) {
				//x509 not signed by x509CA
				ValidityModelData.setValid(false);
				return false;
			}
		} else {
			//Shell model
			try {
				x509.checkValidity(d);
				x509CA.checkValidity(d);
				x509.verify(x509CA.getPublicKey());
				ValidityModelData.setValid(true);
				return true;
			} catch (CertificateException e) {
				//x509 and/or x509CA not valid in this moment
				ValidityModelData.setValid(false);
				return false;
			} catch (SignatureException e) {
				//x509 not signed by x509CA
				ValidityModelData.setValid(false);
				return false;
			}
		}
	}

	/**
	 * Check if example chain is valid by chain or shell model
	 * @param model The model to use (0==chain, 1==shell)
	 * @return True if certificate chain is valid by choosen model, false if not
	 * @throws InvalidKeyException Certificate's public key is invalid
	 * @throws NoSuchAlgorithmException Algorithm unknown
	 * @throws NoSuchProviderException Provider unknown
	 */
	public static boolean checkExampleChain() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException {
		Calendar c = Calendar.getInstance();
		Date d = c.getTime();
		X509Certificate x509CA = ValidityModelData.getX509CA();
		X509Certificate x509 = ValidityModelData.getX509();
		Date certDate = x509.getNotBefore();
		if (ValidityModelData.getModelType() == 0) {
			//Chain model
			try {
				x509.checkValidity(d);
				x509CA.checkValidity(certDate);
				x509.verify(x509CA.getPublicKey());
				ValidityModelData.setValid(true);
				return true;
			} catch (CertificateException e) {
				//x509 not valid in this moment or x509CA not valid when x509 got signed
				ValidityModelData.setValid(false);
				return false;
			} catch (SignatureException e) {
				//x509 not signed by x509CA
				ValidityModelData.setValid(false);
				return false;
			}
		} else {
			//Shell model
			try {
				x509.checkValidity(d);
				x509CA.checkValidity(d);
				x509.verify(x509CA.getPublicKey());
				ValidityModelData.setValid(true);
				return true;
			} catch (CertificateException e) {
				//x509 and/or x509CA not valid in this moment
				ValidityModelData.setValid(false);
				return false;
			} catch (SignatureException e) {
				//x509 not signed by x509CA
				ValidityModelData.setValid(false);
				return false;
			}
		}
	}
	
	/**
	 * Tests if current CA certificate is really from a CA
	 * @return True if certificate is from a CA, false if not
	 * @throws InvalidKeyException Invalid public key
	 * @throws CertificateException Certificate is not valid
	 * @throws NoSuchAlgorithmException Algorithm unknown
	 * @throws NoSuchProviderException Provider unknown
	 */
	public static boolean isCA(X509Certificate x509) throws InvalidKeyException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException {
		try {
			x509.verify(x509.getPublicKey());
			return true;
		} catch (SignatureException e) {
			return false;
		}
	}

}
