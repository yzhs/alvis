package dcs.kva.group01.exercise05.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import dcs.kva.group01.exercise05.Messages;

/**
 * This class represents the UI of the plugin
 * 
 * @author Heinz Hiekmann
 * 
 */
public class CVMComposite extends Composite {

	private static List certificates;
	private static Canvas cnvs;

	protected static void updateCrtLst(Exception ex) {
		if (ex == null){			
			certificates.setItems(Fasade.getNames());
			CVMComposite.paintCanvas();
		} else {
			ErrorDialog.openError(
					Display.getCurrent().getActiveShell(),
					ex.getClass().getSimpleName(),
					ex.getMessage(), 
					new Status(
							IStatus.ERROR,
							CVMComposite.class.toString(),
							IStatus.OK,
							Messages.CVM_grp_KyStr_error,
							ex)
					);
		}
	}
	
	/**
	 * @author Jan Bauerdick
	 */
	private static void paintCanvas() {
		int starts[] = PaintData.getStarts();
		int barLength[] = PaintData.getBarLength();
		int barColor[] = PaintData.getBarColor();
		int connect[] = PaintData.getConnect();
		GC gc = new GC(CVMComposite.cnvs);
		gc.setForeground(CVMComposite.cnvs.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		gc.fillRectangle(gc.getClipping());
		int x = 10, y = 10;
		for (int i = 0; i < barLength.length; i++) {
			gc.setLineWidth(3);
			gc.setForeground(CVMComposite.cnvs.getDisplay().getSystemColor(barColor[i]));
			gc.drawLine(x + starts[i], y, barLength[i] + starts[i] + x, y);
			//System.out.println((x + starts[i]) + ", " + y + ", " + (barLength[i] + x) + ", " + y);
			gc.setForeground(CVMComposite.cnvs.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			gc.setLineWidth(2);
			String ca = "";
			if (i == 0) {
				ca = " (CA)";
			} 
			gc.drawString(Fasade.getNames()[i] + ca, barLength[i] + starts[i] + x, y);
			gc.drawLine(connect[i] + x, y, connect[i] + x, y+30);
			y += 30;
		}
		gc.drawString(Messages.CVM_today, connect[connect.length - 1], y);
		String model;
		if (Fasade.getModel() == 0) {
			model = Messages.CVM_chain_model;
		} else {
			model = Messages.CVM_shell_model;
		}
		if (Fasade.getValid()) {
			gc.setForeground(CVMComposite.cnvs.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			gc.setLineWidth(2);
			String out = Messages.CVM_valid_message + model;
			gc.drawString(out, x, 200);
		} else {
			gc.setForeground(CVMComposite.cnvs.getDisplay().getSystemColor(SWT.COLOR_BLACK));
			gc.setLineWidth(2);
			String out = Messages.CVM_nonvalid_message + model;
			gc.drawString(out, x, 200);
		}
		gc.dispose();
	}

	protected static void showContext(int index) {
		boolean doDelete= MessageDialog.openQuestion(
				Display.getCurrent().getActiveShell(),
				Messages.CVM_shwCntxt_title,
				Fasade.getProperties(index) + "\n" + Messages.CVM_shwCntxt_message);
		if(doDelete){
			Fasade.deleteCertificate(index);
			CVMComposite.updateCrtLst(null);
		}
	}

	public CVMComposite(final Composite parent, final int style)
			throws NoSuchAlgorithmException, CertificateException,
			FileNotFoundException, KeyStoreException, IOException {
		super(parent, style);
		initialize();
	}

	private void initialize() {
		setLayout(new GridLayout(1, false));
		createHead();
		createBody();
	}

	private void createHead() {
		final Composite head = new Composite(this, SWT.NONE);
		head.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		head.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		head.setLayout(new GridLayout());

		final Label head_label = new Label(head, SWT.NONE);
		head_label.setFont(new Font(Display.getDefault(), "Tahoma", 8, SWT.BOLD)); //$NON-NLS-1$
		head_label.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		head_label.setText(Messages.CVM_head_label);

		final StyledText head_description = new StyledText(head, SWT.READ_ONLY);
		head_description.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		head_description.setText(Messages.CVM_head_description);
	}

	private void createBody() {
		final Composite body = new Composite(this, SWT.NONE);
		body.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		body.setLayout(new GridLayout(2, false));

		final Composite leftSide = new Composite(body, SWT.NONE);
		leftSide.setLayoutData(new GridData(SWT.NONE, SWT.FILL, false, true));
		leftSide.setLayout(new GridLayout(1, false));
		this.addGrp_KyStr(leftSide);	
		this.addGrp_ValMod(leftSide);
		this.addGrp_CrtLst(leftSide);
		
		final Composite rightSide = new Composite(body, SWT.NONE);
		rightSide.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		rightSide.setLayout(new GridLayout(1, false));
		this.addCnvs(rightSide);		
	}
	
	private void addGrp_KyStr(final Composite parent){
		final Group grp_KyStr = new Group(parent, SWT.NONE);
		grp_KyStr.setLayout(new GridLayout());
		grp_KyStr.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 0));
		grp_KyStr.setText(Messages.CVM_grp_KyStr);
		final Button btn_KyStr_load = new Button(grp_KyStr, SWT.PUSH);
		btn_KyStr_load.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Fasade.initNewList();
				Exception ex = null;
			    try {
			    	FileDialog fd = new FileDialog(new Shell(), SWT.OPEN);
					Fasade.openFile(fd.open());
					PaintData.init();
//			        fd.setFilterExtensions(new String[]{ "*.txt", "*.doc", ".rtf", "*.*" });
			    } catch (NullPointerException e) {
			    	
				} catch (Exception e) {
					ex = e;
				} finally {
					CVMComposite.updateCrtLst(ex);
					
				}
			}
		});
		btn_KyStr_load.setText(Messages.CVM_grp_KyStr_btn_KyStr_load);
		final Button btn_KyStr_example = new Button(grp_KyStr, SWT.PUSH);
		btn_KyStr_example.addListener(SWT.Selection, new Listener(){
			@Override
			public void handleEvent(Event event) {
				Fasade.initNewList();
				Exception ex = null;
				try {
					Fasade.openExample();
					PaintData.init();
				} catch (Exception e) {
					ex = e;
				} finally {
					CVMComposite.updateCrtLst(ex);					
				}
			}
		});	
		btn_KyStr_example.setText(Messages.CVM_grp_KyStr_btn_KyStr_example);
//		//This is in case user shall be allowed to load a single certificate
//		final Button btn_Crt_load = new Button(grp_KyStr, SWT.PUSH);
//		btn_Crt_load.addListener(SWT.Selection, new Listener() {
//			@Override
//			public void handleEvent(Event event) {
//				Fasade.initNewList();
//				Exception ex = null;
//			    try {
//					Fasade.openFile(new FileDialog(new Shell(), SWT.OPEN).open());
//				} catch (Exception e) {
//					ex = e;
//				} finally {
//					CVMComposite.updateCrtLst(ex);										
//				}
//			}
//		});
//		btn_Crt_load.setText(Messages.CVM_grp_Crt_btn_Crt_load);
	}

	private void addGrp_ValMod(Composite parent){
		final Group grp_ValMod = new Group(parent, SWT.NONE);
		grp_ValMod.setText(Messages.CVM_grp_ValMod);
		grp_ValMod.setLayout(new GridLayout());
		grp_ValMod.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 0));
		final Button btn_ValMod_chain = new Button(grp_ValMod, SWT.RADIO);
		btn_ValMod_chain.setText(Messages.CVM_grp_ValMod_btn_ValMod_chain);
		btn_ValMod_chain.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Fasade.setModel((short)0);
				PaintData.init();
				CVMComposite.paintCanvas();
			}
			
		});
		btn_ValMod_chain.setSelection(true);
		final Button btn_ValMod_shell = new Button(grp_ValMod, SWT.RADIO);
		btn_ValMod_shell.setText(Messages.CVM_grp_ValMod_btn_ValMod_shell);
		btn_ValMod_shell.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Fasade.setModel((short)1);
				PaintData.init();
				CVMComposite.paintCanvas();
			}
			
		});
	}
	
	public void addGrp_CrtLst(Composite parent) {
		Group grp_CrtLst = new Group(parent, SWT.NONE);
		grp_CrtLst.setText(Messages.CVM_grp_CrtLst);
		grp_CrtLst.setLayout(new GridLayout());
		grp_CrtLst.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		certificates = new List(grp_CrtLst, SWT.SINGLE | SWT.BORDER | SWT.V_SCROLL);
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		certificates.setItems(Fasade.getNames());	
		certificates.addSelectionListener(new SelectionListener(){
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				this.showPopup();
			}

			@Override
			public void widgetSelected(SelectionEvent e) {
				this.showPopup();
			}
			
			private void showPopup(){
				int item = certificates.getSelectionIndex();
				CVMComposite.showContext(item);
			}
			
		});
		int listHeight = certificates.getItemHeight() * (Fasade.getNames().length + 2) ;
		Rectangle trim = certificates.computeTrim(0, 0, 0, listHeight);
		gridData.heightHint = trim.height;
		certificates.setLayoutData(gridData);
	}

	private void addCnvs(Composite parent) {
		cnvs = new Canvas(parent, SWT.BORDER);
		cnvs.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		cnvs.setLayout(new GridLayout(1, false));
		cnvs.setBackground(cnvs.getDisplay().getSystemColor(SWT.COLOR_WHITE));
	}
}