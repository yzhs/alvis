package dcs.kva.group01.exercise05.ui;

import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.eclipse.swt.SWT;

/**
 * This class calculates all data needed for certificate chain visualisation
 * @author Jan Bauerdick
 */

public class PaintData {
	
	private static int[] starts;
	private static int[] barLength;
	private static int[] barColor;
	private static int[] connect;
	private static Date today;
	private static ArrayList<X509Certificate> certs;
	
	public static int[] getStarts() {
		return starts;
	}

	public static void setStarts(int[] starts) {
		PaintData.starts = starts;
	}
	
	public static int[] getBarLength() {
		return barLength;
	}

	public static void setBarLength(int[] barLength) {
		PaintData.barLength = barLength;
	}

	public static int[] getBarColor() {
		return barColor;
	}

	public static void setBarColor(int[] barColor) {
		PaintData.barColor = barColor;
	}
	
	public static int[] getConnect() {
		return connect;
	}

	public static void setConnect(int[] connect) {
		PaintData.connect = connect;
	}

	public static Date getToday() {
		return today;
	}

	public static void setToday(Date today) {
		PaintData.today = today;
	}

	public static ArrayList<X509Certificate> getCerts() {
		return certs;
	}

	public static void setCerts(ArrayList<X509Certificate> certs) {
		PaintData.certs = certs;
	}

	/**
	 * Calculate all data needed for visualisation
	 */
	public static void init() {
		try {
		certs = Fasade.getList();
		starts = new int[certs.size()];
		barLength = new int[certs.size()];
		barColor = new int[certs.size()];
		connect = new int[certs.size()];
		Calendar c = Calendar.getInstance();
		today = c.getTime();
		starts[0] = 0;
		Date start = certs.get(0).getNotBefore();
		for (int i = 1; i < certs.size(); i++) {
			Date end = certs.get(i).getNotBefore();
			int days = calculateDifference(start, end);
			starts[i] = days / 10;
		}
		for (int i = 0; i < certs.size(); i++) {
			start = certs.get(i).getNotBefore();
			Date end = certs.get(i).getNotAfter();
			int days = calculateDifference(start, end);
			barLength[i] = days / 10;
		}
		short model = Fasade.getModel();
		if (model == 0) {
			Date begin = certs.get(0).getNotBefore();
			for (int i = 1; i < certs.size(); i++) {
				Date end = certs.get(i).getNotBefore();
				int days = calculateDifference(begin, end);
				connect[i - 1] = days / 10;
			}
			int days = calculateDifference(begin, today);
			connect[connect.length - 1] = days / 10;
			for (int i = 0; i < certs.size() - 1; i++) {
				start = certs.get(i).getNotBefore();
				Date end = certs.get(i).getNotAfter();
				Date check = certs.get(i + 1).getNotBefore();
				if (check.before(start) || check.after(end)) {
					barColor[i + 1] = SWT.COLOR_RED;
				} else {
					barColor[i + 1] = SWT.COLOR_GREEN;
				}
			}
			if (today.before(certs.get(0).getNotBefore()) || today.after(certs.get(0).getNotAfter())) {
				barColor[0] = SWT.COLOR_RED;
			} else {
				barColor[0] = SWT.COLOR_GREEN;
			}
		} else {
			start = certs.get(0).getNotBefore();
			int days = calculateDifference(start, today);
			for (int i = 0; i < connect.length; i++) {
				connect[i] = days / 10;
			}
			for (int i = 0; i < certs.size(); i++) {
				if (today.before(certs.get(i).getNotBefore()) || today.after(certs.get(i).getNotAfter())) {
					barColor[i] = SWT.COLOR_RED;
				} else {
					barColor[i] = SWT.COLOR_GREEN;
				}
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static int calculateDifference(Date a, Date b) {
	    int tempDifference = 0;
	    int difference = 0;
	    Calendar earlier = Calendar.getInstance();
	    Calendar later = Calendar.getInstance();
	 
	    if (a.compareTo(b) < 0) {
	        earlier.setTime(a);
	        later.setTime(b);
	    } else {
	        earlier.setTime(b);
	        later.setTime(a);
	    }
	 
	    while (earlier.get(Calendar.YEAR) != later.get(Calendar.YEAR)) {
	        tempDifference = 365 * (later.get(Calendar.YEAR) - earlier.get(Calendar.YEAR));
	        difference += tempDifference;
	 
	        earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
	    }
	 
	    if (earlier.get(Calendar.DAY_OF_YEAR) != later.get(Calendar.DAY_OF_YEAR)) {
	        tempDifference = later.get(Calendar.DAY_OF_YEAR) - earlier.get(Calendar.DAY_OF_YEAR);
	        difference += tempDifference;
	 
	        earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
	    }
	 
	    return difference;
	}


}
