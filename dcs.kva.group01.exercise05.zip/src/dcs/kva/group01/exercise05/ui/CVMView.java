package dcs.kva.group01.exercise05.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.jcryptool.core.logging.utils.LogUtil;

import dcs.kva.group01.exercise05.ValidityModelPlugin;

public class CVMView extends ViewPart {

	@Override
	public void createPartControl(Composite parent) {
		ScrolledComposite sc = new ScrolledComposite(parent, SWT.H_SCROLL | SWT.V_SCROLL);
		sc.setExpandHorizontal(true);
		sc.setExpandVertical(true);
		CVMComposite c;
		try {
			c = new CVMComposite(sc, SWT.NONE);
			sc.setContent(c);
			sc.setMinSize(c.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		} catch (Exception e) {
			LogUtil.logError(ValidityModelPlugin.PLUGIN_ID, e.toString());
		} 
	}

	@Override
	public void setFocus() {
		// TOD.O Auto-generated method stub
	}
}
