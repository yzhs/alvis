package dcs.kva.group01.exercise05.ui;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import dcs.kva.group01.exercise05.CVMManager;
import dcs.kva.group01.exercise05.ValidityModelData;

/**
 * 
 * @author Heinz Hiekmann
 * 
 * This class is just a layer between business logic and GUI and bundles all ins 
 * and outs from this package.
 *
 */
public class Fasade {
	
	final private static CVMManager vmdm = CVMManager.getInstance();

	public static boolean openFile(String inFilename) throws CertificateException, KeyStoreException, NoSuchAlgorithmException, IOException, InvalidKeyException, NoSuchProviderException{
		return vmdm.loadCertificate(inFilename);
	}
	
	public static boolean openExample() throws CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, InvalidKeyException, NoSuchProviderException{
		return vmdm.loadExampleKeyStore();
	}
	
	public static String[] getNames() {
		return vmdm.getCertificateNames();
	}

	public static String getProperties(int index) {
		return vmdm.getCertificateProperties(index);
	}

	public static X509Certificate deleteCertificate(int index) {
		return vmdm.deleteCertificate(index);
	}
	
	public static void setModel(short type) {
		ValidityModelData.setModelType(type);
	}
	
	public static void initNewList() {
		vmdm.initNewList();
	}
	
	public static boolean getValid() {
		return ValidityModelData.getValid();
	}
	
	public static ArrayList<X509Certificate> getList() {
		return vmdm.getCertificateList();
	}
	
	public static short getModel() {
		return ValidityModelData.getModelType();
	}
}
