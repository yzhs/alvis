package dcs.kva.group01.exercise05;

import org.eclipse.osgi.util.NLS;

/**
 * For english and german messages
 * @author Jan Bauerdick
 *
 */

public class Messages extends NLS {
	
	private static final String BUNDLE_NAME = "dcs.kva.group01.exercise05.messages";
	
	/*
	 * ValidationModelComposite related messages
	 */
	public static String CVM_head_label;
	public static String CVM_head_description;
	public static String CVM_grp_KyStr;
	public static String CVM_grp_KyStr_fd;
	public static String CVM_grp_KyStr_btn_KyStr_load;
	public static String CVM_grp_KyStr_btn_KyStr_example;
	public static String CVM_grp_KyStr_error;
	public static String CVM_grp_Crt;
	public static String CVM_grp_Crt_fd;
	public static String CVM_grp_Crt_btn_Crt_load;
	public static String CVM_grp_ValMod;
	public static String CVM_grp_ValMod_btn_ValMod_chain;
	public static String CVM_grp_ValMod_btn_ValMod_shell;
	public static String CVM_grp_CrtLst;
	public static String CVM_shwCntxt_title;
	public static String CVM_shwCntxt_message;
	public static String CVM_valid_message;
	public static String CVM_nonvalid_message; 
	public static String CVM_chain_model;
	public static String CVM_shell_model;
	public static String CVM_today;	
	
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
