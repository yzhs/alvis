package dcs.kva.group01.exercise05;

import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * Plugin main class
 * @author Jan Bauerdick
 */

public class ValidityModelPlugin extends AbstractUIPlugin {
	
	/** plugin ID. */
	public static final String PLUGIN_ID = "dcs.kva.group05.exercise05.ValidityModel";

}
