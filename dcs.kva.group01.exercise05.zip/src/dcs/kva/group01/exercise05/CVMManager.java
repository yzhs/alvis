package dcs.kva.group01.exercise05;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.security.auth.x500.X500Principal;

public class CVMManager {

	private static CVMManager SINGLETON = null;	
	
	public static CVMManager getInstance(){
		if (CVMManager.SINGLETON == null){
			CVMManager.SINGLETON = new CVMManager();
		}
		return CVMManager.SINGLETON;
	}
	
	private ArrayList<X509Certificate> certificates = null;
	
	private CVMManager(){
		this.certificates = new ArrayList<X509Certificate>();
	}
	
	public String[] getCertificateNames(){
		String[] strArr = new String[this.certificates.size()];
		for ( int i = 0 ; i < this.certificates.size() ; i++ ){
			String temp = this.getName(certificates.get(i));
			strArr[i] = temp;

		}
		return strArr;
	}
	
	//TODO delete:
	public static String getNameOf(X509Certificate inCert){
		String s = inCert.getSubjectX500Principal().getName(X500Principal.RFC1779);
		s = s.split(",")[0];
		s = s.split("=")[1];
		s = s.trim();
		return s;
	}
	
	private String getName(X509Certificate inCert){
		String s = inCert.getSubjectX500Principal().getName(X500Principal.RFC1779);
		s = s.split(",")[0];
		s = s.split("=")[1];
		s = s.trim();
		return s;
	}
	
	private String getOwner(X509Certificate inCert){
		String s = inCert.getSubjectX500Principal().getName(X500Principal.RFC1779);
		s = s.split(",")[1];
		s = s.split("=")[1];
		s = s.trim();
		return s;
	}
	
	private String getLocation(X509Certificate inCert){
		String s = inCert.getSubjectX500Principal().getName(X500Principal.RFC1779);
		String l = s.split(",")[2];
		l = l.split("=")[1].trim();
		String st = s.split(",")[3];	
		st = st.split("=")[1].trim();
		String c = s.split(",")[4];
		c = c.split("=")[1].trim();
		return l + ", " + st + ", " + c;
	}

	public boolean loadCertificate(String inFilename) throws CertificateException, KeyStoreException, NoSuchAlgorithmException, IOException, InvalidKeyException, NoSuchProviderException {
		Action.loadCertificate(inFilename);
		X509Certificate aCertificate = ValidityModelData.getX509();
		return this.add(aCertificate);
	}
	
	public boolean add(X509Certificate aCertificate) {
		boolean isAdded = false;
		if (!this.certificates.contains(aCertificate)){
			isAdded = this.certificates.add(aCertificate);
		}
		return isAdded;
	}

	public boolean loadExampleKeyStore() throws CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, InvalidKeyException, NoSuchProviderException {
		Action.loadExampleChain();
		return this.add(ValidityModelData.getX509CA()) && this.add(ValidityModelData.getX509());
	}

	public String getCertificateProperties(int index) {
		X509Certificate aCert = this.certificates.get(index);
		String s = "Properties of " + this.getName(aCert) + ":\n";
		s += "Owner = " + this.getOwner(aCert) + "\n";
		s += "Location = " + this.getLocation(aCert) + "\n";
		s += "SigAlgName = " + aCert.getSigAlgName() + "\n";
		s += "SigAlgOID = " + aCert.getSigAlgOID() + "\n";
		s += "Type = " + aCert.getType() + "." + aCert.getVersion() + "\n";
		s += "NotAfter = " + aCert.getNotAfter() + "\n";
		s += "NotBefore = " + aCert.getNotBefore() + "\n";
		s += this.checkCertificate() + "\n";
		//s += this.checkExampleChain() + "\n";
		s += this.isCA(aCert) + "\n";
		
		return s;
	}

	private String isCA(X509Certificate x509) {
		String s = "isCA = ";
		try {
			s += Boolean.toString(Action.isCA(x509));
		} catch (Exception e) {
			s += e.getMessage();
		} 
		return s;
	}

	private String checkExampleChain() {
		String s = "checkExampleChain = ";
		try {
			s += Boolean.toString(Action.checkExampleChain());
		} catch (Exception e) {
			s += e.getMessage();
		}
		return s;
	}

	private String checkCertificate() {
		String s = "checkCertificate = ";
		try {
			s += Action.checkCertificate();
		} catch (Exception e) {
			s += e.getClass().toString();
		} 
		return s;
	}

	public X509Certificate deleteCertificate(int index) {
		return this.certificates.remove(index);
	}
	
	public void initNewList() {
		this.certificates = new ArrayList<X509Certificate>();
	}
	
	public ArrayList<X509Certificate> getCertificateList() {
		return certificates;
	}
}
