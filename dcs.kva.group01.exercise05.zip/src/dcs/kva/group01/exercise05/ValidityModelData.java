package dcs.kva.group01.exercise05;

import java.security.KeyStore;
import java.security.cert.X509Certificate;

/**
 * This class contains the main data this plugin needs
 * @author Jan Bauerdick
 */

public class ValidityModelData {
	
	private static short modelType;
	private static X509Certificate x509;
	private static X509Certificate x509CA;
	private static KeyStore cacerts;
	private static KeyStore exampleChain;
	private static boolean valid;
	
	public static short getModelType() {
		return modelType;
	}
	
	public static void setModelType(short modelType) {
		ValidityModelData.modelType = modelType;
	}
	
	public static X509Certificate getX509() {
		return x509;
	}
	
	public static void setX509(X509Certificate x509) {
		ValidityModelData.x509 = x509;
	}
	
	public static X509Certificate getX509CA() {
		return x509CA;
	}
	
	public static void setX509CA(X509Certificate x509CA) {
		ValidityModelData.x509CA = x509CA;
	}
	
	public static KeyStore getCacerts() {
		return cacerts;
	}
	
	public static void setCacerts(KeyStore cacerts) {
		ValidityModelData.cacerts = cacerts;
	}
	
	public static KeyStore getExampleChain() {
		return exampleChain;
	}
	
	public static void setExampleChain(KeyStore exampleChain) {
		ValidityModelData.exampleChain = exampleChain;
	}
	
	public static boolean getValid() {
		return valid;
	}
	
	public static void setValid(boolean valid) {
		ValidityModelData.valid = valid;
	}
	
}
