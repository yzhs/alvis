Plugin läuft natürlich nicht ohne JCrypTool.
Zum Starten JCrypTool in denselben Workspace wie das Plugin
runterladen (http://sourceforge.net/apps/mediawiki/jcryptool/index.php?title=GettingStartedDeveloper#Obtaining_the_JCrypTool_sources)
Anschließend die Datei feature.xml des Projekts
org.jcryptool.visual.feature mit der aus dem Archiv ersetzen.